<?php

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u678356331_gFftU' );

/** Database username */
define( 'DB_USER', 'u678356331_7orxy' );

/** Database password */
define( 'DB_PASSWORD', 'Om1VWCG6MB' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '3mD}hqZMA~Mi9V$5O(`<Vm+3lu_DR6:`i:(UFGufcqLM_B>fFL@tUw%3QBOC[,]Z' );
define( 'SECURE_AUTH_KEY',   'dMPtyBhaWI)^~q<{{--]84[ NTX^= 7hw9x#S@x!zXr5VWkl&:ijMv*~(4|L~}nH' );
define( 'LOGGED_IN_KEY',     '8u||R%+u`w$Fqp Zp!`]YZ;not6p `|/7_&^VLKX/M2_qB>xBb:H#,fI`7XJpo#%' );
define( 'NONCE_KEY',         'Lupw=f[O2~nC>QAMYT^h/f1!7O;&]cLqK)*u,+~<02yCg>S|UI(Ljn6_CCeMh9wB' );
define( 'AUTH_SALT',         'V?H2n#t_ndbyQChI9|(A47bY/M$^E%)~k US#-i%X_A||0j-Z6dpm-kceT9i&[9`' );
define( 'SECURE_AUTH_SALT',  ':-7k,XL}q<}J!5;AOUr]16)Z).twu!Q_<Kt_ujp8:v+$%Q4EW5fG4/sP!TMBWk,k' );
define( 'LOGGED_IN_SALT',    'xw6er(V?lC_Av6%`9WfUtr{gP3HOZH7N+mz2(5vsF4i0;|;l$[;ZV1?{)t9JtV/+' );
define( 'NONCE_SALT',        'iUq+NVfjgBpXom$^g?@f%n:#%6a SyXfA%$NM%=@ z{x;Og/Lz|@]O>e,<D&EPlu' );
define( 'WP_CACHE_KEY_SALT', 'JA[kz.G!B1uGa,~y;!mArx-5^iy4*%P1s8dc`i|[?^&/;#n,a9iHWN2h9?Y3@*P>' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', '1bdb5e1c04e75754a9a292bc56d2539d' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
